# web_subscriber.py
import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class WebSubscriber(Node):
    def __init__(self):
        super().__init__('web_subscriber')
        self.subscription = self.create_subscription(
            String,
            '/target_waypoints',
            self.listener_callback,
            10
        )

    def listener_callback(self, msg: String):
        self.get_logger().info(f"📨 웹에서 받은 메시지: {msg.data}")

def main(args=None):
    rclpy.init(args=args)
    node = WebSubscriber()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

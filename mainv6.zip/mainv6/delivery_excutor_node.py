import rclpy
from rclpy.node import Node

from modules.delivery_queue import DeliveryQueue
from modules.waypoint_manager import WaypointManager
from modules.navigator import Navigator
from modules.battery_monitor import BatteryMonitor

from turtlebot4_navigation.turtlebot4_navigator import TurtleBot4Directions
from nav2_simple_commander.robot_navigator import TaskResult


class DeliveryExecutor(Node):
    def __init__(self):
        super().__init__('delivery_executor')

        self.delivery_queue = DeliveryQueue(self)
        self.waypoint_manager = WaypointManager()
        self.navigator = Navigator(self)
        self.battery_monitor = BatteryMonitor(self, namespace=self.get_namespace())

        self.initialized = False
        self.get_logger().info("✅ 배송 시스템 노드 초기화 완료")

        self.timer = self.create_timer(1.0, self.control_loop)

    def control_loop(self):
        if not self.initialized:
            self.startup_procedure()
            return

        if self.battery_monitor.is_battery_low():
            self.dock_until_charged()
            return

        if self.delivery_queue.is_empty():
            self.get_logger().info("🕓 주문 대기 중 (큐 비어 있음)")
            return

        self.process_delivery()

    def startup_procedure(self):
        self.get_logger().info("🚀 초기화: 스테이 위치로 이동 시도")
        stay_pose = self.navigator.navigator.getPoseStamped(
            [0.4, 1.5],
            TurtleBot4Directions.EAST
        )
        self.navigator.go_to_pose(stay_pose)
        self.initialized = True
        self.get_logger().info("✅ 초기 위치 이동 완료, 주문 대기 시작")

    def dock_until_charged(self, threshold=80.0):
        self.get_logger().warn("🔌 배터리 부족 → 도킹 후 충전 대기")
        # 도킹 동작 생략: 실제 도킹 명령이 있다면 여기에
        while not self.battery_monitor.is_battery_enough_to_depart(threshold):
            rclpy.spin_once(self, timeout_sec=5.0)
            self.get_logger().info(f"⚡ 충전 중... {self.battery_monitor.last_battery_percent:.1f}%")
        self.get_logger().info("✅ 배터리 충분 → 배송 재개 가능")

    def process_delivery(self):
        request = self.delivery_queue.get_next_request()
        if not request:
            return

        address = request["address"]
        product = request["product"]
        self.get_logger().info(f"📦 배송 요청 처리 중: {product} → {address}")

        waypoint_names = [
            f"{product}_hub",      # 허브로 이동
            "wait",                # 허브 앞 대기
            "intersection",
            address,
            "wait",                # 주소 앞 대기
            "intersection",
            "stay"
        ]

        waypoint_data = self.waypoint_manager.get_waypoints_by_names(waypoint_names)

        if not waypoint_data:
            self.get_logger().warn("❌ 유효한 Waypoint 없음. 요청 스킵")
            return

        for i, (name, x, y, direction) in enumerate(waypoint_data):
            if name == "wait":
                self.get_logger().info("⏳ 대기 위치 도착 - 5초 대기 중...")
                self.navigator.wait_at_pose(5.0)
            else:
                pose = self.navigator.navigator.getPoseStamped(
                    [x, y],
                    TurtleBot4Directions[direction.upper()]
                )
                self.get_logger().info(f"➡️ {name} → x={x}, y={y}, 방향={direction}")
                self.navigator.go_to_pose(pose)

                # 목표 도착 대기
                while not self.navigator.navigator.isTaskComplete():
                    rclpy.spin_once(self, timeout_sec=0.5)

                result = self.navigator.navigator.getResult()
                if result != TaskResult.SUCCEEDED:
                    self.get_logger().warn(f"❌ {name} 으로 이동 실패")
                    return  # 실패 시 루프 종료

        self.get_logger().info("✅ 모든 경로 이동 및 대기 완료")

def main(args=None):
    rclpy.init(args=args)
    node = DeliveryExecutor()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
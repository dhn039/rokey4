from collections import deque
from std_msgs.msg import String
from rclpy.node import Node

class DeliveryQueue(Node):
    def __init__(self):
        super().__init__('delivery_queue')
        self.queue = deque()

        self.create_subscription(
            String,
            '/target_waypoints',
            self.delivery_callback,
            10
        )

    def delivery_callback(self, msg: String):
        try:
            address, product = [s.strip() for s in msg.data.split(',')]
            self.queue.append({
                "address": address,
                "product": product
            })
            self.get_logger().info(f"📥 배송 요청 추가: {address} ← {product}")
        except ValueError:
            self.get_logger().warn(f"🚫 잘못된 메시지 형식: '{msg.data}'")

    def is_empty(self) -> bool:
        return len(self.queue) == 0

    def get_next_request(self):
        return self.queue.popleft() if not self.is_empty() else None
class WaypointManager:
    def __init__(self):
        # 이름 → (x, y, 방향)
        self.waypoints = {
            "stay" :(-0.83, 3.05, "WEST"),
            "cross": (-0.83, 3.05, "WEST"),
            "home1": (0.98, 3.65, "SOUTH"),
            "home2": (1.21, 4.93, "EAST"),
            "home3": (-1.58, 4.80, "NORTH"),
            "hub1": (-1.65, 1.74, "NORTH"),
            "hub2": (-1.65, 1.00, "NORTH"),
            "hub3": (-1.65, 0.05, "NORTH"),
            "hub4": (-1.65, -0.73, "NORTH"),
        }

    def get_waypoints_by_names(self, names):
        result = []
        for name in names:
            if name in self.waypoints:
                x, y, direction = self.waypoints[name]
                result.append((name, x, y, direction))
            else:
                print(f"[⚠️] Waypoint '{name}' 없음. 무시됨")
        return result
from turtlebot4_navigation.turtlebot4_navigator import TurtleBot4Navigator, TurtleBot4Directions
from nav2_simple_commander.robot_navigator import TaskResult
from geometry_msgs.msg import PoseStamped
import rclpy
import time


class Navigator:
    def __init__(self, node):
        self.node = node
        self.navigator = TurtleBot4Navigator()

        initial_pose = self.navigator.getPoseStamped(
            [0.4, 1.5],  # stay 위치 기준
            TurtleBot4Directions.EAST
        )
        self.navigator.setInitialPose(initial_pose)
        self.navigator.waitUntilNav2Active()

        self.node.get_logger().info("🧭 Navigator 초기화 완료")

    def follow_waypoints(self, goal_poses: list[PoseStamped]):
        self.node.get_logger().info(f"📍 Waypoint {len(goal_poses)}개 이동 시작")

        if len(goal_poses) == 1:
            self.navigator.goToPose(goal_poses[0])
            self._wait_for_completion()
        else:
            result = self.navigator.followWaypoints(goal_poses)
            self._report_result(result)

    def go_to_pose(self, pose: PoseStamped):
        self.node.get_logger().info("🚶‍♂️ 단일 위치로 이동 시작")
        self.navigator.goToPose(pose)
        self._wait_for_completion()

    def _wait_for_completion(self):
        self.node.get_logger().info("⌛ 목표 도달 대기 중...")
        while not self.navigator.isTaskComplete():
            rclpy.spin_once(self.node, timeout_sec=0.5)

        result = self.navigator.getResult()
        self._report_result(result)

    def _report_result(self, result):
        if result == TaskResult.SUCCEEDED:
            self.node.get_logger().info("✅ 이동 완료")
        else:
            self.node.get_logger().warn("❌ 이동 실패")

    def wait_at_pose(self, seconds: float):
        self.node.get_logger().info(f"⏳ {seconds}초 대기 시작")
        start = self.node.get_clock().now()
        while (self.node.get_clock().now() - start).nanoseconds / 1e9 < seconds:
            rclpy.spin_once(self.node, timeout_sec=0.1)
        self.node.get_logger().info(f"⏳ {seconds}초 대기 종료")
from sensor_msgs.msg import BatteryState

class BatteryMonitor:
    def __init__(self, node, namespace=""):
        self.node = node
        sanitized_ns = namespace.strip('/')
        topic_name = f"/{sanitized_ns}/battery_state" if sanitized_ns else "/battery_state"

        self.last_battery_percent = 100.0  # 초기값
        self.subscription = self.node.create_subscription(
            BatteryState,
            topic_name,
            self.battery_callback,
            10
        )

        self.node.get_logger().info(f"🔋 배터리 모니터링 시작: {topic_name}")

    def battery_callback(self, msg: BatteryState):
        self.last_battery_percent = msg.percentage * 100.0
        self.node.get_logger().info(f"🔋 배터리 잔량: {self.last_battery_percent:.1f}%")

    def is_battery_low(self, threshold: float = 40.0) -> bool:
        return self.last_battery_percent <= threshold

    def is_battery_enough_to_depart(self, threshold: float = 80.0) -> bool:
        return self.last_battery_percent >= threshold
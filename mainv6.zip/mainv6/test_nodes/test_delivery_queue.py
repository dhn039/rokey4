import rclpy
from rclpy.node import Node
from modules.delivery_queue import DeliveryQueue

class DeliveryQueueTest(Node):
    def __init__(self):
        super().__init__('delivery_queue_test')
        self.delivery_queue = DeliveryQueue(self)

        self.timer = self.create_timer(2.0, self.check_queue)

    def check_queue(self):
        if self.delivery_queue.is_empty():
            self.get_logger().info("🕓 큐가 비어있습니다.")
        else:
            request = self.delivery_queue.get_next_request()
            self.get_logger().info(f"📦 큐에서 요청 가져옴: {request}")

def main(args=None):
    rclpy.init(args=args)
    node = DeliveryQueueTest()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()


from modules.waypoint_manager import WaypointManager

def main():
    manager = WaypointManager()

    test_names = ['stay', 'intersection', 'home', 'milk_hub']
    result = manager.get_waypoints_by_names(test_names)

    print("🧭 테스트 웨이포인트 결과:")
    for name, x, y, direction in result:
        print(f" - {name}: x={x}, y={y}, 방향={direction}")

if __name__ == '__main__':
    main()
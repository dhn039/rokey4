
import rclpy
from rclpy.node import Node
from modules.navigator import Navigator
from turtlebot4_navigation.turtlebot4_navigator import TurtleBot4Directions

class NavigatorTest(Node):
    def __init__(self):
        super().__init__('navigator_test')
        self.navigator = Navigator(self)

        pose = self.navigator.navigator.getPoseStamped([0.4, 1.5], TurtleBot4Directions.EAST)

        self.get_logger().info("🚀 테스트 pose 이동 시작")
        self.navigator.go_to_pose(pose)

def main(args=None):
    rclpy.init(args=args)
    node = NavigatorTest()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
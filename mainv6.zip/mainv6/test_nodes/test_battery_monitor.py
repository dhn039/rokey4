# test_nodes/test_battery_monitor.py

import rclpy
from rclpy.node import Node
from modules.battery_monitor import BatteryMonitor

class BatteryMonitorTest(Node):
    def __init__(self):
        super().__init__('battery_monitor_test')
        self.monitor = BatteryMonitor(self)
        self.timer = self.create_timer(2.0, self.check_battery)

    def check_battery(self):
        percent = self.monitor.last_battery_percent
        self.get_logger().info(f"🔋 현재 배터리: {percent:.1f}%")

        if self.monitor.is_battery_low():
            self.get_logger().warn("⚠️ 배터리 부족!")
        else:
            self.get_logger().info("🔋 배터리 충분")

def main(args=None):
    rclpy.init(args=args)
    node = BatteryMonitorTest()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
